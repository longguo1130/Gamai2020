<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes(['verify' => true]);

/* social login */
Route::get('auth/{provider}', 'Auth\LoginController@redirectToSocial')->name('auth.provider');
Route::get('auth/{provider}/callback', 'Auth\LoginController@handleSocialCallback');
Route::get('social-success/{id?}', 'Usercontroller@social_success')->name('user.social');
// we should use callback URI as above on social app setting.


Route::middleware(['auth','verified'])->group(function () {
    /* profile */
    Route::get('profile/{id?}', 'UserController@profile')->name('profile');
    Route::post('profile/{id?}/store', 'UserController@store')->name('profile.store');
    Route::get('detail/profile', 'UserController@profile_detail')->name('profile.detail');
    Route::get('profile/chatting/{id?}', 'UserController@chatting')->name('profile.chatting');
    Route::get('edit/profile/{id?}', 'UserController@profile_edit')->name('profile.edit');
    Route::post('profile/image/upload','UserController@upload_image')->name('profile.image.upload');
    Route::get('profile/image/uploaded','UserController@uploaded_image')->name('profile.image.uploaded');

});

Route::get('/', 'HomeController@index')->name('home');
Route::get('product/bring_products', 'HomeController@bring_products')->name('bring.products');
Route::get('city_autocomplete', 'HomeController@city_autocomplete')->name('city.autocomplete');

/* Products */
Route::resource('products','ProductController');


Route::post('product/image/upload','ProductController@upload_image')->name('product.image.upload');

Route::get('product/image/uploaded','ProductController@uploaded_image')->name('product.image.uploaded');
Route::any('product/set/favorite','ProductController@set_favorite')->name('favor.products');

Route::get('singleproduct/{id}','SingleProductController@index')->name('singleshow');

/* Bidder */
Route::resource('bidders','BidderController');
Route::post('bidder/{id?}/update','BidderController@update')->name('bidders.update');
Route::any('bidder/{id?}/cancel','BidderController@cancel')->name('bidders.cancel');
Route::any('bidder/{id?}/complete','BidderController@complete')->name('bidders.complete');
Route::any('bidder/{id?}/destroy','BidderController@destroy')->name('bidders.destroy');
Route::any('bidder/{id?}/accept/{buyer_id?}','BidderController@accept')->name('bidders.accept');
Route::post('product/{id?}/update','ProductController@update')->name('products.update');
Route::any('product/{id?}/destroy','ProductController@destroy')->name('products.destroy');
Route::any('bidding/list','BidderController@bidding_list')->name('bidding.list');
Route::any('bidder/{id?}/feedback','BidderController@feedback')->name('bidders.feedback');
Route::any('bidder/{id?}/feed','BidderController@provide_feedback')->name('bidders.feed');

/* Chat */
Route::get('/load-latest-messages', 'MessagesController@getLoadLatestMessages');
Route::post('/send', 'MessagesController@postSendMessage');
Route::get('/fetch-old-messages', 'MessagesController@getOldMessages');
Route::any('chat/delete/{id?}','MessagesController@delete')->name('chat.delete');
