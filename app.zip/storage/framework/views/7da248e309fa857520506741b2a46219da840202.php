<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-detail-wrap my-n4 py-5">
        <div class="container">
            <div class="content">
                <div class="form-wrap">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="product_slider_img">
                                <div id="vertical">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div data-thumb="<?php echo e(asset('thumbnails/'.$image->path)); ?>">
                                            <img src="<?php echo e(asset('images/'.$image->path)); ?>" style=" height: 300px;"/>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group profile-price">
                                <h3 class="" style="display: inline-block;"><?php echo e($product->title); ?> </h3>
                                <div style="float: right;">
                                    <a href="javascript:void(0)"  data-toggle="modal" data-target="#shareList"><i class="fa fa-share-alt"></i></a>
                                    <a href="javascript:void(0)"><i class="fa fa-heart-o"></i></a>
                                </div>


                                <!-- Modal -->
                                <div class="modal fade" id="shareList" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h2>Share this listing</h2>
                                            </div>
                                            <div class="modal-body">
                                                <a href="http://facebook.com"><img src="<?php echo e(asset('assets/Asset 2@4x.png')); ?>" alt="" style="width: 44%;height: 40px;"></a>
                                                <a href="http://facebook.com" ><img src="<?php echo e(asset('assets/Asset 2@4x.png')); ?>" alt="" style="width: 40%;height: 40px;"></a>
                                               <div class="copylink" style="text-align: center;margin-top: 10px">
                                                   <input type="text" value="<?php echo e(url()->current()); ?>" id="myInput" style="width: 60%;">
                                                   <button onclick="myFunction()">Copy Link</button>
                                               </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <h6><?php echo e($product->price_format()); ?> </h6>
                            </div>



                            <div class="form-group">
                                <span style="color:red;"><?php echo e($product->created_date()); ?></span>
                            </div>
                            <div class="form-group">
                                <span><?php echo e($product->transaction_type == 1?"FOR:RENT":"FOR:RENT OR SELL"); ?></span>
                            </div>
                            <hr>

                            <?php echo $__env->yieldContent('main_content'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="product-other-wrap py-4">
        <div class="container py-4">
            <h4>Active Bidders</h4>
            <div class="row ">
                <div class="col-md-10">
                    <div class="bidder_list">
                     <?php if(!is_null($bid)): ?>

                    <?php $__currentLoopData = $bid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bidder_content">
                            <div class="title">
                                <span>Bid:<?php echo e($post->bid_price); ?> </span><span>Duration:<?php echo e($post->duration); ?> </span><span>Rating:<?php echo e(App\User::find($post->buyer_id)->verify_status); ?>%</span>
                                <?php if($post->buyer_id == Auth::user()->id): ?>
                                    <?php if($post->status == 1): ?>
                                    <span>Your bid Awarded</span>

                                    <?php elseif($post->status ==0): ?>

                                        <select name="active" id="active" onchange="location = this.value;" class="bid-modify">
                                            <option value="0">Modify</option>
                                            <option value="<?php echo e(route('bidders.edit',['id'=>$post->id])); ?>">Edit</option>
                                            <option value="<?php echo e(route('bidders.destroy',['id'=>$post->id])); ?>">Delete</option>
                                        </select>
                                     <?php else: ?>
                                        <span>your bid was accepted</span>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if($post->seller_id == Auth::user()->id): ?>
                                    <?php if($post->status == 2): ?>

                                    <span class="accept-button"><a href="javascript:void(0);" class="chat-toggle" data-id="<?php echo e($post->buyer_id); ?>" data-user="<?php echo e($post->id); ?>">Open chat</a></span>
                                    <?php else: ?>
                                    <span class="accept-button"><a href="<?php echo e(route('bidders.accept',['buyer_id'=>$post->buyer_id,'id'=>$post->product_id])); ?>">Accept</a></span>
                                        <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <div class="note">
                                <p>Note:<?php echo e($post->comments); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <a href="">See more</a>
                    <hr>
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="related-tab" href="#related" aria-controls="related"
                               data-toggle="tab" role="tab" aria-selected="true">Other related products</a>
                        </li>
                        <li>
                            <a class="nav-link" id="nearby-tab" href="#nearby" aria-controls="nearby" data-toggle="tab"
                               role="tab" aria-selected="false">Nearby</a>
                        </li>
                        <!--<li>-->
                        <!--    <a class="nav-link" id="owner-tab" href="#owner" aria-controls="owner" data-toggle="tab"-->
                        <!--       role="tab" aria-selected="false">Posted by <?php echo e(Auth::user()->name); ?></a>-->
                        <!--</li>-->
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="related" role="tabpanel" aria-labelledby="related-tab">
                        </div>
                        <div class="tab-pane fade" id="nearby" role="tabpanel" aria-labelledby="nearby-tab">
                            Sold...
                        </div>
                        <div class="tab-pane fade" id="owner" role="tabpanel" aria-labelledby="owner-tab">
                            Favor...
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <img src="<?php echo e(asset('images/adv.png')); ?>" style="height: 600px;width:100%;">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>
    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/layouts/product/show.blade.php ENDPATH**/ ?>