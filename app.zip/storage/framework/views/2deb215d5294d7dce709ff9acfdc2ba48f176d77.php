<div class="row">
    <table class="table table-striped">
        <tr>
            <th>Product</th>
            <th>Buyer</th>
            <th>Bid Price</th>
            <th>Duration</th>
            <th>Comments</th>
            <th>Status</th>
            <th>accept/edit</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td></td>
                <td></td>
                <td><?php echo e($post->bid_price); ?></td>
                <td><?php echo e($post->duration); ?></td>
                <td><?php echo e($post->comments); ?></td>
                <td><a href="javascript:void(0);" class="chat-toggle" data-id="<?php echo e($post->buyer_id); ?>" data-user="<?php echo e($post->buyer_info['name']); ?>">Open chat</a></td>
                <td><a href="javascript:void(0)">Award</a></td>
            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH D:\JHN_gamai\resources\views\user\bidding.blade.php ENDPATH**/ ?>