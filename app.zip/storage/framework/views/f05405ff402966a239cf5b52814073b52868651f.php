<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Gamai</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.4.3.1.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/common/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/chat.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('additional_css'); ?>

</head>
<body>
<header class="main_menu" style="display: none;">
    <nav class="navbar navbar-expand-md navbar-light">
        <div class="container_header" >
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(asset('images/gamai-logo.png')); ?>" alt="" style="height: 30px; margin-top: 10px;">
            </a>
            <div class="right-corner">

                <a href="<?php echo e(route('products.create')); ?>" class="sell_btn" >
                    <img src="<?php echo e(asset('assets/Asset 1@4x.png' )); ?>" style="height: 25px;" alt="">
                </a>



                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>

                    <a class="nav-login-btn" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?>

                        <i class="fa fa-user-alt"></i>
                    </a>

                <?php else: ?>
                    <a href="<?php echo e(url('profile')); ?>">
                    <?php if(Auth::user()->provider): ?>
                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="" style="height: 30px;border-radius: 50px;width: 30px;">
                        <?php else: ?>
                        <img src="<?php echo e(asset('avatars/'.Auth::user()->avatar)); ?>" alt="" style="height: 30px;border-radius: 50px;width: 30px;">
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            </div>




        </div>
    </nav>
</header>




<div id="app">
    <main class="">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.js')); ?>" type="text/javascript"></script>

<?php echo $__env->yieldContent('additional_js'); ?>

</body>
</html>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/layouts/home.blade.php ENDPATH**/ ?>