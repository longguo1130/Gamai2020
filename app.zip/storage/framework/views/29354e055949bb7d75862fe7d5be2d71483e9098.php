<div class="category_detail category_kind" style="">
    <ul class="">
        <li class="active" data-id="0">All</li>
        <?php $__currentLoopData = App\Category::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-id="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/home/nav/category.blade.php ENDPATH**/ ?>