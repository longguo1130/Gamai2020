
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm" style="padding-top:4px;padding-bottom:4px;">
    <div class="container_header" >
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/gamai-logo.png')); ?>" alt="" style="height: 30px; margin-top: 10px;">
        </a>
        <div class="right-corner">

            <a href="<?php echo e(route('products.create')); ?>" class="sell_btn" >
                <img src="<?php echo e(asset('assets/Asset 1@4x.png' )); ?>" style="height: 25px;" alt="">
            </a>



            <!-- Authentication Links -->
            <?php if(auth()->guard()->guest()): ?>

                <a class="nav-login-btn" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?>

                    <i class="fa fa-user-alt"></i>
                </a>

            <?php else: ?>
                <a href="<?php echo e(url('profile')); ?>">
                    <?php if(Auth::user()->provider): ?>
                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="" style="height: 30px;border-radius: 50px;width: 30px;">
                    <?php else: ?>
                        <img src="<?php echo e(asset('avatars/'.Auth::user()->avatar)); ?>" alt="" style="height: 30px;border-radius: 50px;width: 30px;">
                    <?php endif; ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/layouts/header.blade.php ENDPATH**/ ?>