<div class="footer">
  <div class="footercontent">
    <div class="footercontent-item">
      <h2>Gamay</h2>
      <p class="copyright">© letgo 2019</p>
      <div class="link-container">
        <a href="#">
          <i class="fa fa-facebook"></i>
        </a>
        <a href="#">
          <i class="fa fa-picture-o"></i>
        </a>
        <a href="#">
          <i class="fa fa-twitter"></i>
        </a>
        <a href="#">
          <i class="fa fa-youtube"></i>
        </a>
      </div>
    </div>
    <div class="footercontent-item">
      <h3>About Gamay</h3>

      <a href="#">Who we are</a>
      <a href="#">What we're up to</a>
      <a href="#">Work with US</a>
      <a href="#">Press</a>

    </div>
    <div class="footercontent-item">
      <h3>Support</h3>

      <a href="#">Trust & safety</a>
      <a href="#">Help Center</a>
      <a href="#">Downloads</a>

    </div>
    <div class="footercontent-item">
      <div>
        <a href="#">Terms and conditions</a>
        <a href="#">Privacy policy</a>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\JHN_gamai\resources\views\layouts\footer.blade.php ENDPATH**/ ?>