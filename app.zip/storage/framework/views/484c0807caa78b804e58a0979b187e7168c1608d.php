
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($index % 4 == 0): ?> <div class="row"> <?php endif; ?>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
            <div class="product-thumb">
                <a href="<?php echo e(route('products.show',['id'=>$post->id])); ?>" class="product-img">
                    <?php if(!empty($post->firstImage['path'])): ?>
                    <img src="<?php echo e(asset('thumbnails/'.$post->firstImage['path'])); ?>" />
                        <?php else: ?>
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" />
                        <?php endif; ?>
                </a>
                <div style="padding:12px 4px;">
                    <p class="title" style="margin-bottom: -12px; margin-top: 0px; "><?php echo e($post->title); ?></p>
                    <div class="product-info">
                        <span><?php echo e(App\City::find($post->city_id)->city); ?></span>
                        <?php if(is_null($user_id)): ?>
                            <a  href="<?php echo e(route('login')); ?>" class="favor_btn favor_btn_<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>" data-user="<?php echo e($user_id); ?>">
                                <img src="<?php echo e(asset('assets/heart.png')); ?>" alt="" style="height: 20px">
                            </a>
                        <?php else: ?>
                            <a  href="javascript:void(0);" class= "favor_btn favor_btn_<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>" data-user="<?php echo e($user_id); ?>">
                                
                                <?php if(in_array($post->id,$favorites)): ?>
                                    <img src="<?php echo e(asset('assets/heart-o.png')); ?>" alt="" style="height: 20px">
                                    <?php else: ?>
                                <img src="<?php echo e(asset('assets/heart.png')); ?>" alt="" style="height: 20px">
                                    <?php endif; ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
            <?php if($index % 4 == 3): ?> <hr></div> <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/products/ajax_page.blade.php ENDPATH**/ ?>