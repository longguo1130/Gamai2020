
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($index % 4 == 0): ?> <div class="row"> <?php endif; ?>
        <div class="col-md-3 ">
            <div class="product-thumb">
                <a href="<?php echo e(route('products.show',['id'=>$post->id])); ?>" class="product-img">
                    <img src="<?php echo e(asset('thumbnails/'.$post->firstImage['path'])); ?>" />
                </a>
                <div style="padding:12px 4px;">
                    <p class="title" style="margin-bottom: 0;"><?php echo e($post->title); ?></p>
                    <div class="product-info">
                        <span>location</span>
                        <?php if(is_null($user_id)): ?>
                            <a href="<?php echo e(route('login')); ?>" class="favor_btn favor_btn_<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>" data-user="<?php echo e($user_id); ?>">
                                <i class="fa fa-heart-o"></i>
                            </a>
                        <?php else: ?>
                            <a href="javascript:void(0);" class="favor_btn favor_btn_<?php echo e($post->id); ?>" data-id="<?php echo e($post->id); ?>" data-user="<?php echo e($user_id); ?>">
                                <i class="fa fa-heart<?php echo e(in_array($post->id,$favorites) ? '' : '-o'); ?>"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
            <?php if($index % 4 == 3): ?> <hr></div> <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\JHN_gamai\resources\views/products/ajax_page.blade.php ENDPATH**/ ?>