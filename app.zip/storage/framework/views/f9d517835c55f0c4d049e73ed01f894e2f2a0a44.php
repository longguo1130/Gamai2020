<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">
                        <h1><a href="<?php echo e(route('home')); ?>">Gamay</a></h1>
                        <p>Buy and sell quickly, safetly and localty. It's time to Gamay!</p>

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <span>Sign in with your</span>
                            <div class="form-group row login-social" style="justify-content: center;">
                                <a href="<?php echo e(url('auth/facebook')); ?>" class="login100-social-item bg1">
                                    <i class="fa fa-facebook"></i> Facebook
                                </a>
                                <a href="<?php echo e(url('auth/google')); ?>" class="login100-social-item bg3">
                                    <i class="fa fa-google"></i> Google
                                </a>
                                <a href="<?php echo e(url('register')); ?>" class="login100-social-item bg2">
                                    SIGN UP
                                </a>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input id="login" type="text" placeholder="Username or email"
                                           class="form-control<?php echo e($errors->has('username') || $errors->has('email') ? ' is-invalid' : ''); ?>"
                                           name="login" value="<?php echo e(old('username') ?: old('email')); ?>" required
                                           autofocus>

                                    <?php if($errors->has('username') || $errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('username') ?: $errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-12">
                                    <input id="password" type="password" placeholder="Password"
                                           class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                           required autocomplete="current-password">

                                    <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-sign" style="">
                                        <?php echo e(__('SIGN IN')); ?>

                                    </button>
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-12">
                                    <input type="checkbox" id="login_privacy">
                                    <label for="login_privacy"> Terms & Conditions and Privacy Police</label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JHN_gamai\resources\views\auth\login.blade.php ENDPATH**/ ?>