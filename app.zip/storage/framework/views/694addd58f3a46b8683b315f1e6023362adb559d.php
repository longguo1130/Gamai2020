<?php $__env->startSection('main_content'); ?>
    <div class="form-group">
        <h3><?php echo e($success); ?></h3>
        <a href="<?php echo e(route('bidders.create',['product_id'=>$product->id])); ?>" class="btn btn-gray">Start Bidding</a>
    </div>
    <hr>
    <div class="form-group">
        <p><?php echo e($product->text); ?></p>
    </div>
    <hr>
    <div class="seller_info_wrap media">
        <?php if(App\User::find($product->user_id)->provider): ?>
            <img src="<?php echo e(App\User::find($product->user_id)->avatar); ?>" alt=""
                 style="width: 128px;height: 128px;border-radius: 50%;">
        <?php else: ?>
            <img src="<?php echo e(asset('avatars/'.App\User::find($product->user_id)->avatar)); ?>" alt=""
                 style="width: 128px;height: 128px;border-radius: 50%;">
        <?php endif; ?>
        <div class="seller_info media-body" style="vertical-align: middle;align-self: center;">
            <span>Seller Name :<?php echo e(App\User::find($product->user_id)->name); ?></span>
            <div>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
                <i class="fa fa-star"></i>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.product.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/products/show_logged.blade.php ENDPATH**/ ?>