<?php $__env->startSection('additional_css'); ?>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="header">
        <div class="header_row container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                Gamay
            </a>
            <ul class="navbar-nav ml-auto" style="flex-direction: row;">
                <li class="nav-item">
                    <a class="nav-link nav-search" href="javascript:void(0);" style="padding: 10px;font-size: 1.3em;">
                        <i class="fa fa-search"></i></a>
                </li>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <?php echo $__env->make('home.nav.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </li>
            <?php else: ?>
                <li class="nav-item">
                    <?php echo $__env->make('home.nav.logged', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </li>
            <?php endif; ?>
            </ul>
        </div>
        <div class="description_container">
            <div class="description">
                <div class="left_desc">
                    <div class="welcome"><h2>Welcome to our site</h2></div>
                    <div class="kind_container">
                        <h3>Buy and sell second hand item</h3>
                        <h3>Post item and start making money</h3>

                        <div class="sell_btn_container">
                            <a href="<?php echo e(route('products.create')); ?>" class="sell_btn">
                                Sell your stuff &nbsp;<i class="fa fa-camera-o"></i>
                            </a>
                            <span class="sell_btn_desc">for 7 days trial</span>
                        </div>
                    </div>
                </div>

                <div class="right_desc">
                    <img class="intro_img" src="<?php echo e(asset('uploads/iphone6s-rosegold-300x400.png')); ?>"/>
                </div>

            </div>
            <div class="container">
                <div class="category_container">
                    <ul class="category_content">
                    <?php echo $__env->make('home.kind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>

        </div>

    </div>


    <div class="products-list">
        <div class="container products-container">
            <div class="row">
                <div class="col-md-10">
                    <div class="product_list" data-page="1" data-last_page="1"></div>
                </div>
                <div class="col-md-2">
                    <img src="<?php echo e('product_images/adv.png'); ?>" style="height: 600px;width:100%;">
                </div>


            </div>
        </div>
    </div>
    <style>

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional_js'); ?>
    <script>
        var query = '<?php echo e($query); ?>';
        var bring_products_url = '<?php echo e(route('bring.products')); ?>';
        var city_autocomplete_url = '<?php echo e(route('city.autocomplete')); ?>';
        var set_favor_url = '<?php echo e(route('favor.products')); ?>';
    </script>
    <script src="<?php echo e(asset('plugins/jQuery-Autocomplete-master/dist/jquery.autocomplete.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/front/front.js')); ?>"></script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JHN_gamai\resources\views\welcome.blade.php ENDPATH**/ ?>