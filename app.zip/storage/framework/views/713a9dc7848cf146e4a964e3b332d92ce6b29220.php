<a id="" class="nav-login-btn" href="javascript:void(0);" onclick="openNav()"><?php echo e(__('Login')); ?>

    <i class="fa fa-user"></i>
</a>
<div class="login_bar sidenav" id="mySidenav">
    <div class="login_bar_section">
        <div class="login_bar_title">
            <a href="<?php echo e(route('login')); ?>">Log in now</a>
            <span>You're not logged in</span>
        </div>
        <img src="<?php echo e(asset('avatars/default.png')); ?>" alt="" style="">
    </div>
    <hr>
    <div class="login_bar_section1">
        <p><i class="fa fa-"></i> About Gamay</p>
        <p><i class="fa fa-"></i> Terms and Condition</p>
        <p><i class="fa fa-"></i> Privacy Policy</p>
    </div>
    <hr>
    <div class="login_bar_section2">
        <button class="btn"><i class="fa fa-facebook"></i></button>
        <button class="btn"><i class="fa fa-instagram"></i></button>
        <button class="btn"><i class="fa fa-twitter"></i></button>
        <button class="btn"><i class="fa fa-youtube"></i></button>
    </div>
</div>
<div id="myCanvasNav" class="overlay_nav" onclick="closeNav()"></div>
<script type="application/javascript">
    function openNav() {
        document.getElementById("mySidenav").style.width = "300px";
        document.getElementById("myCanvasNav").style.width = "100%";
        document.getElementById("myCanvasNav").style.opacity = "0.8";
    }
    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("myCanvasNav").style.width = "0%";
        document.getElementById("myCanvasNav").style.opacity = "0";
    }
</script>
<?php /**PATH D:\JHN_gamai\resources\views\home\nav\login.blade.php ENDPATH**/ ?>