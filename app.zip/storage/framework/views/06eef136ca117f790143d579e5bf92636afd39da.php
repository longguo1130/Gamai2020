<?php $__env->startSection('main_content'); ?>



    <form  class="bid-content">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <div class="row">
                <div class="col-md-6">

                    <span>You already sent a bid to this product</span>

                    <h2><?php echo e($success); ?></h2>


                </div>

            </div>
        </div>

    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.product.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/bidder/show.blade.php ENDPATH**/ ?>