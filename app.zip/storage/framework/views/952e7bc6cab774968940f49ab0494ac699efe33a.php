<?php echo e($slot); ?>

<?php /**PATH /home2/fivestu2/public_html/gamai/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>