
<div class="row">
    <table class="table table-striped">
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Number of Bids</th>
            <th>Status</th>

        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('products.show',['id'=>$post->id])); ?>"><?php echo e($post->title); ?></a></td>
                <td><?php echo e($post->price); ?></td>
                <td><?php echo e($post->bidsNum()); ?></td>
                
                <td>
                    <?php if($post->status == 0): ?>
                        Waiting
                        <?php elseif($post->status ==2): ?>
                        <select name="active" id="active" onchange="location = this.value;">
                            <option value="0">Active</option>
                            <option value="<?php echo e(route('bidders.cancel',['id'=>$post->id])); ?>">Looking</option>
                            <option value="<?php echo e(route('bidders.complete',['id'=>$post->id])); ?>">Completed</option>
                        </select>

                        <?php else: ?>
                        Completed
                        <?php endif; ?>

                </td>
            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/selling.blade.php ENDPATH**/ ?>