<?php $__env->startSection('main_content'); ?>



    <form class="bid-content" >
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <div class="row">
                <div class="col-md-6">
                   <span>This is sold product</span>



                </div>

            </div>
        </div>

    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.product.sold', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/bidder/sold.blade.php ENDPATH**/ ?>