<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-detail-wrap my-n4 py-5">
        <div class="container">
        <div class="content">
            <div class="form-wrap">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="product_slider_img">
                            <div id="vertical">
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div data-thumb="<?php echo e(asset('thumbnails/'.$image->path)); ?>">
                                        <img src="<?php echo e(asset('images/'.$image->path)); ?>"/>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="form-group profile-price">
                            <h3 class="" style="display: inline-block;"><?php echo e($product->title); ?></h3>
                            <div style="float: right;">
                                <a href=""><i class="fa fa-share-alt"></i></a>
                                <a href=""><i class="fa fa-heart-o"></i></a>
                            </div>
                        </div>
                        <div class="form-group">
                            <h2>$<?php echo e($product->price); ?></h2>
                        </div>

                        <div class="form-group">
                            <span><?php echo e($product->created_at); ?></span>
                        </div>
                        <div class="form-group">
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-gray">Log in to Bid</a>
                        </div>
                        <hr>
                        <div class="form-group">
                            <p><?php echo e($product->text); ?></p>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="product-other-wrap py-4">
        <div class="container py-4">
            <div class="row ">
                <div class="col-md-10">
                    <div class="product_list"></div>
                    <a href="">See more</a>
                    <hr>
                </div>
                <div class="col-md-2">
                    <img src="<?php echo e('product_images/adv.png'); ?>" style="height: 600px;width:100%;">
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>
    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JHN_gamai\resources\views\products\show.blade.php ENDPATH**/ ?>