<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/chat_full.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div id="frame">
        <div id="sidepanel">
            <div id="profile">
                <div class="wrap">
                    <h3>Chats</h3>


                </div>

               <ul style="display: flex; list-style: none;padding-left: 0px; justify-content: space-around; margin: 0 -20px;" class="chat-group">
                   <li  data-status="group-all">All</li>
                   <li  data-status="group-selling">Selling</li>
                   <li  data-status="group-buying">Buying</li>
                   <li  data-status="group-blocked">Blocked</li>
               </ul>
            </div>
            <div id="contacts">
                <ul class="contact-list">
                    <li class="contact choose-option" style="display: flex;justify-content: space-around" hidden >
                        <div class="choose-options-back" style="width: 50px; margin-top: 17px;">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                        </div>
                        <div class="choose-options-viewprofile">
                            <a href="" class="viewprofile"><img src="<?php echo e(asset('avatars/default.png')); ?>" alt="" width="30px;"><p>view profile</p></a>
                        </div>
                        <div class="choose-options-block">
                            <img src="<?php echo e(asset('avatars/default.png')); ?>" alt="" width="30px;"><p>block</p>
                        </div>
                        <div class="choose-options-delete">
                            <a href="" class="delete-chat"><img src="<?php echo e(asset('avatars/default.png')); ?>" alt="" width="30px;"><p>delete chat</p></a>
                        </div>
                    </li>

                    <?php $__currentLoopData = $bid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li class="contact  <?php echo e($bidder->getStatus()); ?> chat-toggle-man" data-id="<?php echo e($bidder->getInfo()->id); ?>"
                                data-user="<?php echo e($bidder->getInfo()->id); ?>">

                                <div class="wrap">
                                    
                                    <?php if($bidder->getInfo()->provider): ?>
                                        <img src="<?php echo e($bidder->avatar()); ?>" alt="" style="height: 40px;">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('avatars/'.$bidder->avatar())); ?>" alt="" style="height: 40px;"/>
                                    <?php endif; ?>
                                    <div class="meta">
                                        <p class="name"><?php echo e($bidder->getInfo()->name); ?></p>
                                        <a href="javascript:void(0)" class="view-option" data-id = "<?php echo e($bidder->getInfo()->id); ?>"><img src="<?php echo e(asset('assets/toggle.png')); ?>"  alt="" style="margin-top: -50px; float: right ;"></a>

                                    </div>
                                </div>

                            </li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </ul>
            </div>

        </div>
        <div class="content">
            <div class="contact-profile">
                <img src="<?php echo e(asset('avatars/'.Auth::user()->avatar)); ?>" alt="" style="height: 50px;width: 50px;"/>
                <p><?php echo e(Auth::user()->username); ?></p>
                <div class="social-media">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </div>
            </div>
            <div class="messages">

            </div>
            <div class="message-input">
                <div class="wrap">
                    <input type="text" placeholder="Write your message..." class="full-chat-input"/>
                    
                    <button class="full-btn-chat" data-to-user="">Send</button>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>
        var profile_url = '<?php echo e(route('profile')); ?>/';
        var delete_chat_url  = '<?php echo e(route('chat.delete')); ?>/';
    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chat_full.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/chatting.blade.php ENDPATH**/ ?>