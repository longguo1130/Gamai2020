<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-success">
        <div class="container">
            <div class="row ">
                <div class="success col-8">
                    <div class="success-dialog">

                        <h2>Congratulations!</h2>
                        <form class="form-horizontal" action="<?php echo e(route('user.social',['user'=>$user])); ?>">


                            <div class="form-group <?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                               
                                <lable>Input your username</lable>
                                <input id="username" type="text" placeholder="username" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="" required autocomplete="username">
                                <?php if(isset($duplicate)): ?><strong style="color:red;"><?php echo e($duplicate); ?></strong><?php endif; ?>
                            </div>
                            <div class="form-group">
                                <button type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="overlay_success"></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>

    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/social_success.blade.php ENDPATH**/ ?>