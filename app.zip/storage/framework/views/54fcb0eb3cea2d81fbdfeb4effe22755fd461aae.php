<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Gamay</title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.4.3.1.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('additional_css'); ?>


</head>
<body>
<div id="app">

    <main class="py-4" style="margin-top: 5%;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

</div>

<!-- jQuery 2.1.4 -->
<script src="<?php echo e(asset('plugins/jQuery/jQuery-2.1.4.min.js')); ?>" type="text/javascript"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo e(asset('js/bootstrap.4.3.1.min.js')); ?>" type="text/javascript"></script>
<?php echo $__env->yieldContent('additional_js'); ?>

</body>
</html>
<?php /**PATH D:\JHN_gamai\resources\views\layouts\login.blade.php ENDPATH**/ ?>