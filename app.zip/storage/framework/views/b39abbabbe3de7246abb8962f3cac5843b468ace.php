<?php $__env->startSection('main_content'); ?>
    <div class="form-group">
        <div class="row">
        <div class="col-md-6">
            <span>Bid</span>
            <input type="text" class="form-control">
        </div>
        <div class="col-md-6">
            <span>Duration</span>
            <input type="text" class="form-control">
        </div>
        </div>
    </div>
    <div class="form-group">
        <div class="row">
        <div class="col-md-12">
            <span>Comments</span>
            <textarea type="text" class="form-control"></textarea>
        </div>
        </div>
    </div>
    <div class="form-group">
        <a href="" class="btn btn-wide btn-gray">Submit</a>
        <a href="" class="btn btn-wide btn-default">Discard</a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.product.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JHN_gamai\resources\views\bidder\create.blade.php ENDPATH**/ ?>