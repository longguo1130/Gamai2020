<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-success">
        <div class="container">
            <div class="row ">
                <div class="success col-8">
                    <div class="success-dialog">
                        <h2>Congratulations!</h2>
                        <h5>Your listing has posted</h5>
                        <h6><b><a href="<?php echo e(route('products.edit',['id'=>$product->id])); ?>">Add mored details</a></b></h6>
                        <h5>OR</h5>
                        <a href="<?php echo e(route('products.create')); ?>" class="sell_btn">Post another listing</a>
                        <div class="footer-social">
                            <a href="http://facebook.com">
                                <img src="<?php echo e(asset('assets/Asset 11@4x.png')); ?>" alt="" height="20px">
                            </a>
                            <a href="http://linkedin.com">
                                <img src="<?php echo e(asset('assets/Asset 12@4x.png')); ?>" alt="" height="20px">
                            </a>
                            <a href="http://twitter.com">
                                <img src="<?php echo e(asset('assets/Asset 13@4x.png')); ?>" alt="" height="20px">
                            </a>
                            <a href="http://youtube.com">
                                <img src="<?php echo e(asset('assets/Asset 14@4x.png')); ?>" alt="" height="20px">
                            </a>

                        </div>
                        <h5>Share the listing with your friends</h5>
                    </div>
                </div>
                <div class="overlay_success"></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>

    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/products/create_success.blade.php ENDPATH**/ ?>