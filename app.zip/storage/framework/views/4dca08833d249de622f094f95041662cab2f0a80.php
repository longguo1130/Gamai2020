<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-3 ">
            <div class="product-thumb">

                <?php if(!is_null($post->productInfo)): ?>
                    <a href="<?php echo e(route('products.show',['id'=>$post->productInfo->id])); ?>"><img src="<?php echo e(asset('images/'.$post->productInfo->firstImage['path'])); ?>" /></a>
                    <?php else: ?>
                    <a href="/"><img src="<?php echo e('product_images/no_image.png'); ?>" /></a>
                <?php endif; ?>
                
                <p class="title"><?php echo e($post->title); ?></p>
                PHP<p><?php echo e($post->productInfo['price']); ?></p>
                <a href="#"><img src="<?php echo e(asset('assets/heart-o.png')); ?>" alt="" style="height: 20px"/a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        No products now...
    <?php endif; ?>
</div>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/favorite.blade.php ENDPATH**/ ?>