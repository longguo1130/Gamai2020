<div class="row">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 ">
            <div class="product-thumb">
                <?php if(!is_null($post->firstImage)): ?>
                    <a href="<?php echo e(route('products.show',['id'=>$post->id])); ?>"><img src="<?php echo e(asset('images/'.$post->firstImage['path'])); ?>" /></a>
                    <?php else: ?>
                    <a href="/"><img src="<?php echo e('product_images/no_image.png'); ?>" /></a>
                <?php endif; ?>
                
                <p class="title"><?php echo e($post->title); ?></p>
                PHP<p><?php echo e($post->price); ?></p>
                <a href="#"><i class="fa fa-heart-o"></i></a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\JHN_gamai\resources\views/user/selling.blade.php ENDPATH**/ ?>