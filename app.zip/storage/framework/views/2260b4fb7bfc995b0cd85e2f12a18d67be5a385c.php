<div class="category_detail category_sort" style="">
    <ul class="">
        <li class="active" data-id="0">Date(most recent)</li>
        <li data-id="1">Price: low to high</li>
        <li data-id="2">Price: high to low</li>
        <li data-id="2">Price: high to low</li>
    </ul>
</div><?php /**PATH D:\JHN_gamai\resources\views/home/nav/sort.blade.php ENDPATH**/ ?>