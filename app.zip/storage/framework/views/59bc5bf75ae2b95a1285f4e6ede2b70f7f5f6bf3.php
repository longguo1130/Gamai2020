
    
        
            
                
                    
                    
                    
                
                
                
                
                
            
        
    
        
    

<div class="row">
    <table class="table table-striped">
        <tr>
            <th>Product</th>
            <th>User</th>
            <th>Transaction Type</th>
            <th>Date Completed</th>
            
            
            

        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($post->sellerInfo['id'] == Auth::user()->id): ?>
            <tr>
                <td><a href="<?php echo e(route('products.show',['id'=>$post->productInfo['id']])); ?>"><?php echo e($post->productInfo['title']); ?></a></td>
                <td><?php echo e($post->buyer_info['username']); ?></td>

                <td>Seller</td>
                <td><?php echo e($post->updated_at); ?></td>
                
                
                
            </tr>
            <?php endif; ?>
                <?php if($post->buyer_info['id'] == Auth::user()->id): ?>
                    <tr>
                        <td><a href="<?php echo e(route('products.show',['id'=>$post->productInfo['id']])); ?>"><?php echo e($post->productInfo['title']); ?></a></td>
                        <td><?php echo e($post->sellerInfo['username']); ?></td>
                        <td>Buyer</td>
                        <td><?php echo e($post->updated_at); ?></td>
                        
                        
                        
                    </tr>
                <?php endif; ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/sold.blade.php ENDPATH**/ ?>