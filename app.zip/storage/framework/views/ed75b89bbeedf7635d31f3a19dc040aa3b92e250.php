<?php
/**
 * This is used in full chat page
 */
?>
<ul class="full-chat-area">
    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li class="<?php echo e($message->from_user == \Auth::user()->id ? 'sent' : 'replies'); ?>"> 
            
            <p><?php echo e($message->content); ?></p>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li>There is no history</li>
    <?php endif; ?>
</ul>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/chat/chat-content.blade.php ENDPATH**/ ?>