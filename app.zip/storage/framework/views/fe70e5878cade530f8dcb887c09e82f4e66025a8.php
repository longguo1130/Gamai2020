<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="title m-b-md">
        </div>

        <div class="panel-body">
            <div class="container" style="padding:12px;border: 1px solid #ddd; border-radius: 12px;">
                <div class="row">
                    <div class="col-md-4" style="border-right: 1px solid #ddd;">
                        <div class="media">
                            <div class="d-flex" style="padding-right: 15px;">
                                <img src="<?php echo e(asset('avatars/default.png')); ?>" alt=""
                                     style="width: 128px;height: 128px;border-radius: 50%;">
                            </div>
                            <div class="media-body" style="vertical-align: middle;align-self: center;">
                                <h2>Ling Guo</h2>
                                <p><i class="fa fa-map-marked"></i> China</p>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-8">
                        <h4>Verification Status</h4>
                        <div class="progress">
                            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: 50%;"></div>
                        </div>
                        Verified with <span></span>
                        <a href="">Edit profile <i class="fa fa-user"></i></a>
                    </div>

                </div>
            </div>


            <section>
                <div class="container">
                    <div class="profile-contents">
                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="active-tab" href="#active" aria-controls="active"
                                   data-toggle="tab" role="tab" aria-selected="true">active</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="selling-tab" href="#selling" aria-controls="selling"
                                   data-toggle="tab" role="tab" aria-selected="true">Selling</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="bidding-tab" href="#bidding" aria-controls="bidding"
                                   data-toggle="tab" role="tab" aria-selected="true">Bidding</a>
                            </li>
                            <li>
                                <a class="nav-link" id="sold-tab" href="#sold" aria-controls="sold" data-toggle="tab"
                                   role="tab" aria-selected="false">Sold</a>
                            </li>
                            <li>
                                <a class="nav-link" id="favor-tab" href="#favor" aria-controls="favor" data-toggle="tab"
                                   role="tab" aria-selected="false">Favorites</a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="active" role="tabpanel"
                                 aria-labelledby="active-tab">

                            </div>
                            <div class="tab-pane fade" id="selling" role="tabpanel" aria-labelledby="selling-tab">
                            </div>
                            <div class="tab-pane fade" id="bidding" role="tabpanel" aria-labelledby="bidding-tab">
                            </div>
                            <div class="tab-pane fade" id="sold" role="tabpanel" aria-labelledby="sold-tab">
                                Sold...
                            </div>
                            <div class="tab-pane fade" id="favor" role="tabpanel" aria-labelledby="favor-tab">
                                Favor...
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    </div>

    <style>
        .profile-contents .nav.nav-tabs {
            display: block;
            border: none;
            padding: 10px 0px;
        }

        .profile-contents .nav.nav-tabs li {
            display: inline-block;
            margin-right: 7px;
        }

        .profile-contents .nav.nav-tabs li a.active {
            background: #2f7dfc;
            color: #fff;
            border-color: #2f7dfc;
        }

        .profile-contents .nav.nav-tabs li a {
            line-height: 38px;
            background: #fff;
            border: 1px solid #eeeeee;
            padding: 0 30px;
            color: #2a2a2a;
            font-size: 13px;
            font-weight: normal;
            border-radius: 50px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional_js'); ?>
    <script>
        var profile_detail_url = '<?php echo e(route('profile.detail')); ?>';

        $(function () {
            $.ajax({
                url: profile_detail_url,
                type: "get",
                datatype: "json",
                data: {},
                success:function(data) {
                    $('#selling').html(data.selling_html);
                    $('#sold').html(data.sold_html);
                    $('#favor').html(data.favor_html);
                    $('#bidding').html(data.bidding_html);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JHN_gamai\resources\views/user/profile.blade.php ENDPATH**/ ?>