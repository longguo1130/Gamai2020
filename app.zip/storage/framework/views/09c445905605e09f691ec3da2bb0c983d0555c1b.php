<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Gamay</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.4.3.1.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/common/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('additional_css'); ?>

</head>
<body>
<header class="main_menu" style="display: none;">
    <nav class="navbar navbar-expand-md navbar-light">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                Gamay
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">

                    <?php echo $__env->make('home.kind', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <li class="nav-item" style="">
                        <a class="nav-link nav-search" href="javascript:void(0);" style="padding: 10px;font-size: 1.3em;">
                            <i class="fa fa-search"></i></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('products.create')); ?>" class="sell_btn">
                            Sell your stuff &nbsp;<i class="fa fa-camera"></i>
                        </a>
                    </li>


                    <!-- Authentication Links -->
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-login-btn" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?>

                                <i class="fa fa-user-alt"></i>
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php if(auth()->user()->avatar): ?>
                                    <img src="<?php echo e(auth()->user()->avatar); ?>" class="user-avatar" alt="">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('avatars/default.png')); ?>" class="user-avatar" alt="">
                                <?php endif; ?>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('profile',['id'=>Auth::user()->id])); ?>">
                                    <?php echo e(Auth::user()->name); ?>

                                </a>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                      style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>


<div class="search_menu" style="display: none;">
    <form id="product-search-form" action="<?php echo e(route('home')); ?>" method="GET" style="">
        <i class="fa fa-search"></i>
        <input type="text" name="q" class="navbar-search" placeholder="Search stuff" value="<?php echo e($query); ?>">
    </form>
</div>

<div id="app">
    <main class="">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- jQuery 2.1.4 -->
<script src="<?php echo e(asset('plugins/jQuery/jQuery-2.1.4.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" type="text/javascript"></script>
<!-- Bootstrap 3.3.2 JS -->
<script src="<?php echo e(asset('js/bootstrap.4.3.1.min.js')); ?>" type="text/javascript"></script>
<!-- <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script> -->
<script src="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.js')); ?>" type="text/javascript"></script>

<?php echo $__env->yieldContent('additional_js'); ?>

</body>
</html>
<?php /**PATH D:\JHN_gamai\resources\views/layouts/home.blade.php ENDPATH**/ ?>