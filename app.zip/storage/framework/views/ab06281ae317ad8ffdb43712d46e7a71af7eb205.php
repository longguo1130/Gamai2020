<div class="row">
    <table class="table table-striped">
        <tr>
            <th>Product</th>
            <th>Seller</th>
            <th>Price</th>
            <th>Bid Price</th>
            <th>Duration</th>
            <th>Comments</th>
            <th>Status</th>

        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('products.show',['id'=>$post->productInfo['id']])); ?>"><?php echo e($post->productInfo['title']); ?></a></td>
                <td><?php echo e($post->sellerInfo['username']); ?></td>
                <td><?php echo e($post->price); ?></td>
                <td><?php echo e($post->bid_price); ?></td>
                <td><?php echo e($post->duration); ?></td>
                <td><?php echo e($post->comments); ?></td>
                <td><?php echo e($post->status == 2 ? 'accepted':'pending'); ?></td>
            </tr>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/bidding.blade.php ENDPATH**/ ?>