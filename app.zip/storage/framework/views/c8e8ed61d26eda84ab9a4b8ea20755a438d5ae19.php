<?php $__env->startSection('main_content'); ?>



    <form id="bid-info" class="bid-content" method="POST" action="<?php echo e(route('bidders.update',['id'=>$bid->id])); ?>">
        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <div class="row">
                <div class="col-md-6">

                    <span>Bid</span>

                    <input id="bid_price" type="text" class="form-control" name="bid_price" value="<?php echo e($bid->bid_price); ?>">

                </div>
                <div class="col-md-6">
                    <span>Duration</span>
                    <select class="form-control" name="duration" id="duration">
                        <option value="0">Select Duration</option>
                        <option value="Day" <?php echo e(old('duration') == 1 ? 'selected' : ''); ?>>Day</option>
                        <option value="Week" <?php echo e(old('duration') == 2 ? 'selected' : ''); ?>>Week</option>
                        <option value="Month" <?php echo e(old('duration') == 3 ? 'selected' : ''); ?>>Month</option>
                        <option value="Year" <?php echo e(old('duration') == 4 ? 'selected' : ''); ?>>Year</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="row">
                <div class="col-md-12">
                    <span>Comments</span>
                    <textarea id="comments" type="text" name="comments" class="form-control" ><?php echo e($bid->comments); ?></textarea>
                </div>
            </div>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-info">Submit</button>

        </div>
    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.product.editbid', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/bidder/edit.blade.php ENDPATH**/ ?>