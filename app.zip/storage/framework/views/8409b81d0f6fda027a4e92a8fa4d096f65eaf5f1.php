<?php $__env->startSection('main_content'); ?>



    <form class="bid-content" >
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <div class="row">
                <div class="col-md-6">
                    <?php if($product->status == 0): ?>


                        <div class="form-group">
                            <a href="<?php echo e(route('products.edit',['id'=>$product->id])); ?>" class="btn btn-gray" style="width: 40%;">Edit Post</a>
                            <a href="<?php echo e(route('products.destroy',['id'=>$product->id])); ?>" class="btn btn-gray" style="width: 40%;">Delete</a>
                        </div>
                        <hr>
                        <div class="form-group">
                            <p><?php echo e($product->text); ?></p>
                        </div>
                        <hr>
                        <div class="media">
                            <div class="d-flex" style="padding-right: 15px;">
                                <?php if(App\User::find($product->user_id)->provider): ?>
                                    <img src="<?php echo e(App\User::find($product->user_id)->avatar); ?>" alt=""
                                         style="width: 128px;height: 128px;border-radius: 50%;">
                                <?php else: ?>
                                <img src="<?php echo e(asset('avatars/'.App\User::find($product->user_id)->avatar)); ?>" alt=""
                                     style="width: 128px;height: 128px;border-radius: 50%;">
                                    <?php endif; ?>
                            </div>
                            <div class="media-body" style="vertical-align: middle;align-self: center;">
                                <h6><?php echo e(Auth::user()->name); ?></h6>
                                <p><i class="fa fa-map-marked"></i> China</p>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div>

                        </div>
                    <?php elseif($product->status ==2): ?>
                        <span>You are discussing with customer</span>
                        <?php else: ?>
                        <span>This is your sold product</span>

                        <?php endif; ?>




                </div>

            </div>
        </div>

    </form>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.product.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/bidder/seller.blade.php ENDPATH**/ ?>