<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Gamai</title>

    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/bootstrap.4.3.1.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/chat.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('additional_css'); ?>


</head>
<body>
<div id="app">

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<!-- jQuery 2.1.4 -->
<script src="<?php echo e(asset('plugins/jQuery/jQuery-2.1.4.min.js')); ?>" type="text/javascript"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('js/bootstrap.4.3.1.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('plugins/fancybox-master/dist/jquery.fancybox.min.js')); ?>" type="text/javascript"></script>
<script>
    var base_url = '<?php echo e(url("/")); ?>';
</script>
<script src="https://js.pusher.com/4.1/pusher.min.js"></script>
<script src="<?php echo e(asset('js/chat.js')); ?>"></script>



<?php echo $__env->yieldContent('additional_js'); ?>

</body>
</html>
<?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/layouts/app.blade.php ENDPATH**/ ?>