<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-detail-wrap my-n4 py-5">
        <div class="container">
            <div class="content">
                <div class="form-wrap">
                    <div class="row">
                        <div class="col-sm-5">
                            <div class="product_slider_img">
                                <div id="vertical">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div data-sthumb="<?php echo e(asset('thumbnails/'.$image->path)); ?>">
                                            <?php if(!empty($image->path)): ?>
                                                <img src="<?php echo e(asset('thumbnails/'.$image->path)); ?>"/>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-7">
                            <div class="form-group profile-price">
                                <h3 class="" style="display: inline-block;"><?php echo e($product->title); ?> posted by <?php echo e($product->seller); ?></h3>
                                <div style="float: right;">
                                    <a href=""><i class="fa fa-share-alt"></i></a>
                                    <a href=""><i class="fa fa-heart-o"></i></a>
                                </div>
                            </div>
                            <div class="form-group">
                                <h2><?php echo e($product->price_format()); ?></h2>
                            </div>

                            <div class="form-group">
                                <span><?php echo e($product->created_date()); ?></span>
                            </div>
                            <hr>

                            <?php echo $__env->yieldContent('main_content'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>
    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/layouts/product/editbid.blade.php ENDPATH**/ ?>