<div class="form-group">
    <a href="" class="btn btn-gray">Start Bidding</a>
</div>
<hr>
<div class="form-group">
    <p><?php echo e($product->text); ?></p>
</div>
<hr>
<div class="seller_info_wrap media">
    <img src="<?php echo e(asset('avatars/default.png')); ?>" class="seller_avatar" alt="">
    <div class="seller_info media-body" style="vertical-align: middle;align-self: center;">
        <span>Seller Name ,<?php echo e($product->location_id); ?></span>
        <div>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
            <i class="fa fa-star"></i>
        </div>
    </div>

</div><?php /**PATH D:\JHN_gamai\resources\views\products\part\info.blade.php ENDPATH**/ ?>