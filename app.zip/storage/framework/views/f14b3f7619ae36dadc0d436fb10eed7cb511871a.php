<div class="category_detail category_kind" style="">
    <ul class="">
        <li class="active" data-id="0">All</li>
        <li data-id="1">Addf</li>
        <li data-id="2">Wwe fgh</li>
    </ul>
</div><?php /**PATH D:\JHN_gamai\resources\views\home\nav\category.blade.php ENDPATH**/ ?>