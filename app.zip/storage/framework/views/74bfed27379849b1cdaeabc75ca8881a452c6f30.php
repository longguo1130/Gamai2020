<?php $__env->startSection('additional_css'); ?>
    <link href="<?php echo e(asset('css/common/lightslider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/page/product/product.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="product-success">
        <div class="container">
            <div class="row ">
                <div class="success col-8">
                    <div class="success-dialog">
                        <h2>Congratulations!</h2>

                        <form class="form-horizontal" action="<?php echo e(route('bidders.feedback',['bid'=>$bid])); ?>">
                            <div class="form-group">
                                <label for="">Feedback</label>
                            </div>
                            <div class="form-group">
                                <select name="feedback_type" id="feedback_type">
                                    <option value="0">Positive</option>
                                    <option value="1">Negative</option>
                                    <option value="2">Other</option>
                                </select>

                            </div>
                            <div class="form-group">
                                <label for="">How your experience</label>
                            </div>

                            <div class="form-group">
                              <?php for($i=1;$i<6;$i++): ?>  <span class="fa fa-star" data-id = "<?php echo e($i); ?>"></span><?php endfor; ?>
                                  <input type="text" class="rating" name="rating" value="" hidden>

                            </div>
                            <div class="form-group">
                                <textarea name="comments" id="comments" cols="30" rows="5"></textarea>
                            </div>
                            <div class="form-group">
                                <button type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="overlay_success"></div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional_js'); ?>
    <script>
        $(function(){

            $('.fa-star').on('click',function () {
               let checked_num = $(this).data('id');
               $('.rating')[0].value = checked_num;
                for ( var i=0; i<5; i++) {
                    // use myclass[i] here
                    $('.fa-star')[i].style.color = "#636b6f";

                }
                for ( var i=0; i<checked_num; i++) {
                    // use myclass[i] here
                    $('.fa-star')[i].style.color = "orange";

                }
            });
        });
    </script>
    <script src="<?php echo e(asset('js/lightslider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/page/product/show.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/fivestu2/public_html/gamai/resources/views/user/feedback.blade.php ENDPATH**/ ?>