<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\productImages;
class Feedback extends Model
{
    protected $table = 'feedback';

    public function created_date(){
        //return Carbon::parse($this->created_at)->diffForHumans();
        return $this->created_at->diffForHumans();
    }
}
