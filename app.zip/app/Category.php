<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;
Use \Carbon\Carbon;
use App\Product;
use App\productImages;
class Category extends Model
{
    protected $table = 'category';

}
