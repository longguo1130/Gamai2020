<div class="category_detail category_price" style="">
    <div class="" style="margin-bottom: 8px;">
        <input type="text" class="min_price price_input" value="" placeholder="Min">
        <label for="" style="width:16%;text-align: center;">to</label>
        <input type="text" class="max_price price_input" value="" placeholder="Max">
    </div>
    <div class="" style="">
        <a href="javascript:void(0);" class="btn btn-default btn-reset">Reset</a>
        <a href="javascript:void(0);" class="btn btn-primary btn-apply" style="float:right;">Apply</a>
    </div>
</div>